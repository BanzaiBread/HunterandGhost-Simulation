----------------------------------------------------------------------------
This program simulates a group of hunter detecting a ghost in a house, 
The hunters move through the house collecting evidence
while the ghost tries to scare the hunters out of the house 
----------------------------------------------------------------------------

##Summary
The program initiates with the hunters selection allowing the user to select their name and id,
then it runs a simulation of the hunters trying to chase evidence of the ghost across the simulated house,
there are three pieces of evidence the hunters must find to catch the ghost,


## Simulation ends:
1. When the hunters gets maxes out their bored attribute (an attribute which increases 
   when the ghost is not in their current room) and the hunters exit the house
2.The ghost is found 


## Executing
For the code to compile, unzip the tar file with tar -xvf HunterandGhost_Simulation.tar -C /pathtoDirectory 
go to that directory and enter the line: make 
the terminal searches for a makefile it will compile and create the executable named proj
type ./simu to execute the code 

## File Purposes

- main.c
    1. Creates all the structure
    2. Creates all the threads and joins them
    3. Free up all the memory

- defs.h
    1. Defines all the structures
    2. Has all the function protoypes 

- helpers.c 
    1. Sets up which rooms are in the house 
    2. Contains the log functions which documents the actions of each hunter and the ghost

- house.c
    1. Initialize the House strucuture

- room.c
    1. Initialize the room structure
    2. Holds the function for connecting rooms

- ghost.c
    1. Initialize the ghost structure
    2. Contains the behaviour of the ghost

- hunter.c 
    1. Initialize the room structure
    2. Contains the behaviour of the hunter

- evidence.c
    1. Initialize the CaseFile structure
    2. Holds the function that determines CaseFiles is solved

